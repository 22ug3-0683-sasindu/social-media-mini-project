# 🌐 The Interactor – Social Post Prototype
A simple React app where users can create posts and view posts fetched from an external API.

## 🔧 How to Run
1. Install Node.js
2. Open terminal in folder
3. Run:
   npm install
   npm run dev

## 🧠 Features
- React with Hooks (useState, useEffect)
- JSONPlaceholder API Integration
- Responsive Layout
- Like and Comment counters

