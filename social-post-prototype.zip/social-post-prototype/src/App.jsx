import React, { useState, useEffect } from "react";
import PostCreator from "./components/PostCreator";
import SocialPost from "./components/SocialPost";
import "./styles/App.css";

export default function App() {
  const [posts, setPosts] = useState([]);

  
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts?_limit=5")
      .then((res) => res.json())
      .then((data) => {
        
        const realisticTexts = [
          "Just finished our mini React project for class! 🚀 Feeling proud of our teamwork.",
          "Technology keeps changing every day — staying updated is the real challenge! 💻",
          "Exploring how APIs connect data between apps. It’s actually fun once you get it! 🌐",
          "Learning React Hooks today — useState and useEffect are so useful! 💡",
          "Can’t believe how AI tools make development faster and easier! 🤖"
        ];

        const formatted = data.map((item, index) => ({
          id: item.id,
          author: `User ${item.userId}`,
          text: realisticTexts[index % realisticTexts.length],
          image: "",
          likes: Math.floor(Math.random() * 10),
          comments: Math.floor(Math.random() * 5)
        }));

        setPosts(formatted);
      })
      .catch((err) => console.error("Error fetching API:", err));
  }, []);

  
  function addNewPost(newPost) {
    const post = {
      id: Date.now(),
      author: "You",
      text: newPost.text,
      image: newPost.image,
      likes: 0,
      comments: 0
    };
    setPosts([post, ...posts]);
  }

  return (
    <div className="app-container">
      <h1>🌐 The Interactor</h1>
      <PostCreator onPost={addNewPost} />
      <div className="feed">
        {posts.map((p) => (
          <SocialPost key={p.id} {...p} />
        ))}
      </div>
    </div>
  );
}
