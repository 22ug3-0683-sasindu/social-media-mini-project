import React, { useState } from "react";
import "../styles/Post.css";

export default function PostCreator({ onPost }) {
  const [text, setText] = useState("");
  const [image, setImage] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!text.trim()) return alert("Text is required!");
    onPost({ text, image });
    setText("");
    setImage("");
  }

  return (
    <form className="post-creator" onSubmit={handleSubmit}>
      <textarea
        placeholder="What's happening?"
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows="3"
      />
      <input
        type="url"
        placeholder="Image URL (optional)"
        value={image}
        onChange={(e) => setImage(e.target.value)}
      />
      <button type="submit">Post</button>
    </form>
  );
}
