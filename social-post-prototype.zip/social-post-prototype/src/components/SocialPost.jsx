import React, { useState } from "react";
import "../styles/Post.css";

export default function SocialPost({ author, text, image, likes, comments }) {
  const [likeCount, setLikeCount] = useState(likes);

  return (
    <div className="post-card">
      <h3>{author}</h3>
      <p>{text}</p>
      {image && <img src={image} alt="Post" />}
      <div className="actions">
        <button onClick={() => setLikeCount(likeCount + 1)}>❤️ {likeCount} Likes</button>
        <span>💬 {comments} Comments</span>
      </div>
    </div>
  );
}
